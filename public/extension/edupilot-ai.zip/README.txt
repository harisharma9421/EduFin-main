EduPilot AI — Chrome Extension (build output)
=============================================

This folder is a build-ready Chrome extension. To install:

1. Open chrome://extensions
2. Toggle on "Developer mode" (top-right)
3. Click "Load unpacked"
4. Select this folder

To rebuild from source:
   cd extension
   cp .env.example .env.local   # add your Groq API key
   npm install
   npm run build

After loading the extension once, you can simply refresh any open tab and
the floating EduPilot bubble will appear at the bottom-right corner.
